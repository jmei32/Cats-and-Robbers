﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

public class target : MonoBehaviour {

	public targetManager targetManager;

	public void OnCollisionEnter (Collision collision){
		targetManager.removeTarget();

		Debug.Log("Collision detected");
		Destroy(gameObject);
	}
}
