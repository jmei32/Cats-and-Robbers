﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class targetManager : MonoBehaviour {

	public int numTargets = 5;

	void Start() {
	}

	// Update is called once per frame
	public void removeTarget () {
		numTargets--;

		if(numTargets <= 0)
		{
			Application.LoadLevel(0);
		}
	}
}
