﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class box_script : MonoBehaviour {
	public targetManager targetManager;
	public GameObject box;

	Rigidbody rb;

	public void OnCollisionEnter (Collision collision){
		targetManager.removeTarget();

		GameObject broken_box = Instantiate (box, (this.transform.position) + Vector3.down, this.transform.rotation) as GameObject;

		Debug.Log ("broken box");
		Destroy(gameObject);
	}
}
