﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class NavAgent : MonoBehaviour {

	private NavMeshAgent agent;

	public Transform Player;

	public float speed;

	// Use this for initialization
	void Start () {

	}

	// Update is called once per frame
	void Update () {

		agent = gameObject.GetComponent<NavMeshAgent>();

		agent.destination = (Player.position);

		//looks at player if robber can't get to player
		if (pathComplete ()) {
			Vector3 targetPostition = new Vector3( Player.position.x, 
				this.transform.position.y, 
				Player.position.z ) ;
			transform.LookAt( targetPostition ) ;
			//agent.Warp(Player.position);
			//transform.position += transform.forward * speed * Time.deltaTime;
		}
	}

	protected bool pathComplete()
	{
		if (agent.remainingDistance > 0 && agent.remainingDistance <= agent.stoppingDistance)
			return true;

		return false;
	}
}
