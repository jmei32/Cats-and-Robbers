﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class targetManager : MonoBehaviour {

	public int numTargets = 7;

	// Update is called once per frame
	public void removeTarget () {
		numTargets--;
		Debug.Log(numTargets);

		if(numTargets <= 0)
		{
			Cursor.visible = true;
			GameObject.FindGameObjectWithTag ("music").GetComponent<AudioSource>().Play();
			SceneManager.LoadScene (4);

			AudioSource audioSource = GameObject.FindGameObjectWithTag ("music").GetComponent<AudioSource> ();
			audioSource.PlayDelayed (1f);
			audioSource.volume = 0.78f;
		}
	}
}
