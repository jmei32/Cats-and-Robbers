﻿using UnityEngine;
using UnityEngine.AI;
using System.Collections;


public class Patrol : MonoBehaviour {

	public Transform[] points;
	private int destPoint = 0;
	private NavMeshAgent agent;

	public GameObject Player;
	public float DistanceToAttack = 10.0f;

	bool isAttacking = false;

	void Start () {
		agent = GetComponent<NavMeshAgent>();

		// Disabling auto-braking allows for continuous movement
		// between points (ie, the agent doesn't slow down as it
		// approaches a destination point).
		agent.autoBraking = false;

		GotoNextPoint();
	}


	void GotoNextPoint() {
		// Returns if no points have been set up
		if (points.Length == 0)
			return;

		// Set the agent to go to the currently selected destination.
		agent.destination = points[destPoint].position;

		// Choose the next point in the array as the destination,
		// cycling to the start if necessary.
		destPoint = (destPoint + 1) % points.Length;
	}

	void Attack() {
		agent.destination = (Player.transform.position);
		isAttacking = true;
	}


	void Update () {

		// Calculate distance to target
		float DistanceToTarget = CalculateDistance(Player); 

		// If at the DistanceToAttack or less, then attack
		if (DistanceToTarget <= DistanceToAttack || isAttacking) {
			Attack ();
		} else if (!isAttacking) {
			// Choose the next destination point when the agent gets
			// close to the current one.
			if (!agent.pathPending && agent.remainingDistance < 0.5f)
				GotoNextPoint();
		}

	}

	// Simple implementation of Pythagorean formula to calculate distance
	float CalculateDistance(GameObject MyTarget)
	{
		// Grab references to positions of player and zombie as a Vector3 
		Vector3 MyPosition = transform.position;
		Vector3 TargetPosition = MyTarget.transform.position;

		// Assuming you're working with x and z values here in 3d space, ignoring height.
		// If not, use the y values instead. 
		float X = Mathf.Abs(MyPosition.x - TargetPosition.x);
		float Z = Mathf.Abs(MyPosition.z - TargetPosition.z);
		float D = Mathf.Sqrt(Mathf.Pow(X, 2) + Mathf.Pow(Z, 2));

		return Vector3.Distance(MyPosition, TargetPosition); 
	}

}