﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PressurePlate : MonoBehaviour {

	public static bool pressure;
	public Material pPlate;

	public Transform burglar;
	public float minDist;

	public Rigidbody door;
	float amount = 5000f;

	public Animator[] lights;

	public AudioClip creakSound;

	// Use this for initialization
	void Start () {
		pressure = false;
		pPlate.color = Color.red;

		door.freezeRotation = true;
	}

	void Update(){
		if (Vector3.Distance (transform.position, burglar.position) <= minDist) {	// player collided
			if(pressure == false)
			{
				Debug.Log("Pressure Plate hit");
				pPlate.color = Color.green;
				pressure = true;

				door.freezeRotation = false;
				door.AddForce (-transform.right * amount, ForceMode.Impulse);
				door.useGravity = true;
				AudioSource.PlayClipAtPoint(creakSound, door.transform.position);

				foreach (var light in lights){
					light.SetTrigger("Activate");
				}
			}
		} 
	}
}
