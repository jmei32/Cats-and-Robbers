﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class ButtonScript : MonoBehaviour {

	public GameObject backgroundMusic;

	public void PlayGame() {
		SceneManager.LoadScene (1);
		GameObject.FindGameObjectWithTag ("music").GetComponent<AudioSource> ().volume = 0f;

	}
	public void LoadInstructions() {
		SceneManager.LoadScene (2);
	}
	public void LoadMenu() {
		Cursor.visible = true;
		SceneManager.LoadScene (0);
	}

	public void LoadCredits(){
		SceneManager.LoadScene (3);
	}
}
