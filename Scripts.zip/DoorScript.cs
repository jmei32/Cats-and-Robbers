﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class DoorScript : MonoBehaviour {
	public Rigidbody door;
	public float amount = 5000f;

	public void Start () {
		door = this.GetComponent<Rigidbody> ();
		door.freezeRotation = true;
	}

	public void openDoor() {
		door.freezeRotation = false;
		door.AddForce (-transform.right * amount, ForceMode.Impulse);
		door.useGravity = true;
	}
}
