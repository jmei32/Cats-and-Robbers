﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.SceneManagement;

public class PlayerController : MonoBehaviour
{

	public float speed = 25.0f;
	public float turboSpeed = 35.0f;
	public float baseSpeed = 20.0f;
	public float climbSpeed = 35.0f;
	public float turboClimbSpeed = 40.0f;
	public float rotationSpeed = 90;
	public float force = 10f;
	Rigidbody rb;
	Transform t;

	bool grounded = false;
	bool canClimb = false;
	int turboMode = 0;

	public int startingStamina = 100;
	public int currentStamina;
	public Slider staminaSlider;

	public Transform gameCamera;

	public AudioSource source;
	public AudioClip jumpSound;

	Animator animator;

	void Start () {
		rb = GetComponent<Rigidbody> ();
		t = GetComponent<Transform> ();
		currentStamina = startingStamina;	
		Cursor.visible = false;

		animator = this.GetComponent<Animator>();
	}

	void Awake() {
		source = GetComponent<AudioSource>();
	}

	void OnCollisionEnter (Collision col)
	{
		if (col.gameObject.tag == "ground" || col.gameObject.tag == "furniture") {
			grounded = true;
			canClimb = true;
			Debug.Log("Touching furniture");
		}

		if(col.gameObject.tag == "target"){
			Debug.Log("Collision detected");

			rb.AddForce(-transform.forward * 500, ForceMode.Force);
		}

		if (col.gameObject.tag == "robber") {
			Cursor.visible = true;
			GameObject.FindGameObjectWithTag ("music").GetComponent<AudioSource>().Play();
			SceneManager.LoadScene (5);

			AudioSource audioSource = GameObject.FindGameObjectWithTag ("music").GetComponent<AudioSource> ();
			audioSource.PlayDelayed (1f);
			audioSource.volume = 0.78f;
		}
	}

	void OnCollisionStay(Collision col)
	{
		if(col.gameObject.tag == "furniture")
		{
			canClimb = true;
		}
	}

	void OnCollisionExit(Collision col)
	{
		if(col.gameObject.tag == "furniture")
			canClimb = false;
		if(col.gameObject.tag == "ground")
			rb.velocity -= this.transform.up * speed * Time.deltaTime * 10f;
			
	}

	void Update()
	{
		animator.SetBool("move", false);

		if(turboMode == 1){
			speed = turboSpeed;
		}
		else{
			speed = baseSpeed;
		}

		if (Input.GetKey(KeyCode.W)){
			rb.velocity += this.transform.forward * speed * Time.deltaTime;
			//transform.position = transform.position + Camera.main.transform.forward * speed * Time.deltaTime;
			animator.SetBool("move", true);
		}
		else if (Input.GetKey(KeyCode.S)){
			rb.velocity -= this.transform.forward * speed * Time.deltaTime;
			//transform.position = transform.position - Camera.main.transform.forward * speed * Time.deltaTime;
			animator.SetBool("move", true);
		}

		Quaternion CharacterRotation = gameCamera.transform.rotation;
		CharacterRotation.x = 0;
		CharacterRotation.z = 0;

		transform.rotation = CharacterRotation;

		if (Input.GetKey (KeyCode.D))
			rb.velocity += this.transform.right * speed * Time.deltaTime;
			//this.transform.Translate(speed * Time.deltaTime,0,0);
		else if (Input.GetKey (KeyCode.A))
			rb.velocity -= this.transform.right * speed * Time.deltaTime;
			//this.transform.Translate(-speed * Time.deltaTime,0,0);

		if (Input.GetKeyDown(KeyCode.Space) && grounded) {
			source.PlayOneShot(jumpSound);

			if(turboMode == 1)
			{
				rb.AddForce(t.up * force * 4000);
			}
			else{
				rb.AddForce (t.up * force * 3000);
			}			
			grounded = false;
		}

		if(Input.GetKey(KeyCode.E) && canClimb){
			if(turboMode == 1)
			{
				//rb.AddForce ((t.up * force * 15)/3);
				rb.velocity += this.transform.up * turboClimbSpeed * Time.deltaTime;
			}
			else{
				//rb.AddForce ((Vector3.up * force * 10)/3);
				rb.velocity += this.transform.up * climbSpeed * Time.deltaTime;

			}
		}

		if(Input.GetKey(KeyCode.LeftShift) && currentStamina > 0)
		{
			turboMode = 1;
			currentStamina--;
			staminaSlider.value = currentStamina;
		}
		else{
			turboMode = 0;
		}
	}

	public void FixedUpdate(){
		GetComponent<Rigidbody>().AddForce(Physics.gravity * 2, ForceMode.Acceleration);
	}

}
