﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SocialPlatforms.Impl;

public class target : MonoBehaviour {

	public targetManager targetManager;
	public GameObject broken_prefab;

	public AudioSource source;
	public AudioClip crashSound;

	Rigidbody rb;

	void Start () {
		//rb.useGravity = true;
	}

	void Awake() {
		source = GetComponent<AudioSource>();
	}

	public void OnCollisionEnter (Collision collision){
		if(collision.gameObject.tag == "ground"){
			AudioSource.PlayClipAtPoint(crashSound, transform.position);

			targetManager.removeTarget();
			GameObject broken_box = Instantiate (broken_prefab, (this.transform.position) + Vector3.down, this.transform.rotation) as GameObject;
			Destroy(gameObject);
		}
	}
}
