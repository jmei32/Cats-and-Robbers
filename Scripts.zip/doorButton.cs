﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class doorButton : MonoBehaviour {
	public void OnCollisionEnter (Collision collision){
		Debug.Log("DoorButton detected");
		Destroy (gameObject);
		Destroy(GameObject.FindGameObjectWithTag("door"));
	}
}
